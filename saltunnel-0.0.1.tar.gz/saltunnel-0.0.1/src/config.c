//
//  config.c
//  saltunnel
//

#include "config.h"

int config_connection_timeout_ms = 0;
