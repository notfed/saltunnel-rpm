//
//  consttime.h
//  saltunnel
//
//  Constant-time comparison.
//

#ifndef consttime_h
#define consttime_h

int consttime_are_equal(const unsigned char* x, const unsigned char* y, unsigned int len);

#endif /* consttime_h */
