//
//  math.h
//  saltunnel
//

#ifndef math_h
#define math_h

#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))

#endif /* math_h */
