//
//  saltunnel_init.h
//  saltunnel
//
//  When saltunnel will be used in a threaded application, this must be called
//  at application startup, or before spawning any threads.
//

#ifndef saltunnel_init_h
#define saltunnel_init_h

void saltunnel_init(void);

#endif /* saltunnel_init_h */
