//
//  consttime.test.h
//  saltunnel-test
//

#ifndef consttime_test_h
#define consttime_test_h

void consttime_tests(void);

#endif /* consttime_test_h */
