//
//  hex2bin.test.h
//  saltunnel
//

#ifndef hex2bin_test_h
#define hex2bin_test_h

void hex2bin_tests(void);

#endif /* hex2bin_test_h */
