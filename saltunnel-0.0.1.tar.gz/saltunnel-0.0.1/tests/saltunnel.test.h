//
//  test.h
//  saltunnel
//

#ifndef saltunnel_tests_h
#define saltunnel_tests_h

void large_bidirectional_test(void);
void single_packet_bidirectional_test(void);
void saltunnel_tcp_forwarder_tests(void);
void two_packet_bidirectional_test(void);
void edge_case_bidirectional_tests(void);
void calculate_filled_buffers_tests(void);

#endif /* test_h */
