//
//  log.test.h
//  saltunnel
//

#ifndef log_test_h
#define log_test_h

void log_test(void);

#endif /* log_test_h */
