//
//  waitlist.test.h
//  saltunnel
//

#ifndef waitlist_test_h
#define waitlist_test_h

#include <stdint.h>

void waitlist_set_now_ms(int64_t now_ms);

void waitlist_tests(void);

#endif /* waitlist_test_h */
