//
//  nonce.test.h
//  saltunnel
//

#ifndef noncetest_h
#define noncetest_h

#include "nonce.test.h"
#include <stdio.h>

void nonce_tests(void);

#endif /* noncetest_h */
