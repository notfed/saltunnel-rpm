//
//  hypercounter.test.h
//  saltunnel-test
//

#ifndef hypercounter_test_h
#define hypercounter_test_h

void hypercounter_tests(void);

#endif /* hypercounter_test_h */
