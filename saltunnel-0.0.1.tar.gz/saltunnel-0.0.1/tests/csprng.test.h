//
//  csprng.test.h
//  saltunnel-test
//

#ifndef csprng_test_h
#define csprng_test_h

void csprng_tests(void);

#endif /* csprng_test_h */
