//
//  cache_test.h
//  saltunnel
//

#ifndef cache_test_h
#define cache_test_h

void cache_test(void);

#endif /* cache_test_h */
